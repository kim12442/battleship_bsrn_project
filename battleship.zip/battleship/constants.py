import datetime

COPYRIGHT = f'© {datetime.date.today().year}  [1394427, Hong Thien Kim Ngo, hong.ngo@stud.fra-uas.de]  [1349537, Khalid Zoufal, khalid.zoufal@stud.fra-uas.de]  [1330834, Ahmed Zoufal, ahmed.zoufal@stud.fra-uas.de]  [1306693, Mohamed-Amin Abbou, Mohamed-amin.abbou@stud.fra-uas.de]  [1350513, Taha Tabouy, taha.tabouy@stud.fra-uas.de]'
DESCRIPTION = 'Schiffe versenken in der Shell'
DEFAULT_PLAYER_NAME = 'Spieler'
MOVE_COUNTDOWN = 0

MIN_SIZE = 8
MAX_SIZE = 20

DEFAULT_BOARD_SIZE = 10

GAME_PORT = 1337

MAX_RECV = 1024 * 1024

WINNER_TEXT = """
                                                                            
  ██████  ███████ ██     ██  ██████  ███    ██ ███    ██ ███████ ███    ██  
 ██       ██      ██     ██ ██    ██ ████   ██ ████   ██ ██      ████   ██  
 ██   ███ █████   ██  █  ██ ██    ██ ██ ██  ██ ██ ██  ██ █████   ██ ██  ██  
 ██    ██ ██      ██ ███ ██ ██    ██ ██  ██ ██ ██  ██ ██ ██      ██  ██ ██  
  ██████  ███████  ███ ███   ██████  ██   ████ ██   ████ ███████ ██   ████  
                                                                            
"""

LOSER_TEXT = """
                                                                      
 ██    ██ ███████ ██████  ██       ██████  ██████  ███████ ███    ██  
 ██    ██ ██      ██   ██ ██      ██    ██ ██   ██ ██      ████   ██  
 ██    ██ █████   ██████  ██      ██    ██ ██████  █████   ██ ██  ██  
  ██  ██  ██      ██   ██ ██      ██    ██ ██   ██ ██      ██  ██ ██  
   ████   ███████ ██   ██ ███████  ██████  ██   ██ ███████ ██   ████  
                                                                      
"""
