BOATS = {
    'Schlachtschiff': {
        'count': 1,
        'size': 5
    },
    'Kreuzer': {
        'count': 2,
        'size': 4
    },
    'Zerstörer': {
        'count': 3,
        'size': 3
    },
    'U-Boot': {
        'count': 4,
        'size': 2
    }
}
